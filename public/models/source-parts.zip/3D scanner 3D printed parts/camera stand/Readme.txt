There are 2 variants of the camera stand. It can be printed in 1 piece on printers with a print bed longer then 220mm, this print does require support material.

For printers under 220mm the stand can be printed in 2 parts (no support needed)